//#define     _ECLIPSEDEBUG 1
//#define   _NOCHANGES   1
/*
 *      Author: Brian Piccioni DocumentedDesigns.com
 *      (c) Brian Piccioni
 *
 *      This is free software made available under the GNU General Public License(GPL) version 3 or greater.
 *      see https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 *      It can be modified, copied, etc. provided:
 *      1) Original authorship of Brian Piccioni and DocumentDesigns.com is prominently noted
 *      2) Any derivative work or copy also be released under GPL V3 or later with the attribution mentioned in 1)
 *
 *      This software is release "as is" and with no warranty.
 *
 *      Please contact brian@documenteddesigns.com with any feature requests/bug notifications
 *      If you want me to fix a problem or add a feature I will expect you to provide sample files showing
 *      the problem or feature need.
 *
 *  Note:   set project properties g++ -static -static-libgcc -static-libstdc++ -g -static-libgcc -static-libstdc++
 *          use external console debug configuration
 *
 * Changes:
 *  V0.400      Full re-write c++, GUI with wxWidgets
 *  V0.410      Move towards KiCad style (modules, nets as objects, export/import was is file
 *              Use wxWidgets file library
 *
 *
 * See  https://github.com/wxWidgets/wxWidgets/releases/v3.1.1 for wxWidgets installation
 * Note: things like libraries and compiler flags are *** really *** important. See manual.txt for details.
 */

#include "RenumLiterals.h"
#include "RenumDefines.h"
#include "RenumPrototypes.h"
#include "RenumStructures.h"

#include <wx/wx.h>
#include <string>

#include "RenumKicadPCB_Base.h"

#include <wx/filedlg.h>
#include "RenumKicadPCBClasses.h"
#include "FileName.h"


IMPLEMENT_APP(MyApp)

bool MyApp::OnInit()
{
    G_RenumMenu = new RenumKicadPCB(NULL, wxID_ANY,
        wxT("RenumKiCadPCB V0.401"), wxDefaultPosition, 
                DEFAULTMAINDIALOG, 
                        wxDEFAULT_DIALOG_STYLE | wxRESIZE_BORDER | wxFULL_REPAINT_ON_RESIZE );
    LoadParameterFile(  );
    G_RenumMenu = new RenumKicadPCB(NULL, wxID_ANY,
        wxT("RenumKiCadPCB V0.401"), wxDefaultPosition, G_MainDialogSize);
    G_RenumMenu->SetParameters();
    G_PCBInputFile.buffer.clear();              //Make sure nothing is there
    LoadPCBFile( G_PCBInputFile );
    G_RenumMenu->Show(true);
    return true;
}

//
// Convert a wxSize to string format x, y
//
std::string SizetoString( wxSize Size )
{
    return( std::to_string( Size.x ) + ',' + std::to_string(Size.y));
}

//
// Convert a string format x,y to wxSize
//
wxSize  StringtoSize(std::string &SizeString, wxSize default )
{
wxSize  retval;
        retval.x = atoi(SizeString.c_str());
        retval.y = atoi(SizeString.substr(( SizeString.find(',') + 1 )).c_str());
        if ((0 == retval.x) || (0 == retval.y))
            retval = default;
        return(retval);
}

FileName ParamFileName(void)
{
FileName    paramfile;
    paramfile = PARAMETERFILENAME;

#ifndef  __linux__      //Windows can't write to install directory
    paramfile.Directory = getenv("APPDATA") 
        + (std::string) PARAMETERDIRECTORY;     //In Windows write to the appdata folder

    struct stat dirinfo;
    if (0 != stat(paramfile.FullName().c_str(), &dirinfo))   //If not there
        if (0 != _mkdir(paramfile.FullName().c_str()))        //Try create it
        {
            paramfile.FullName().insert(0, "Can't create parameter directory ");
            ShowError(paramfile.FullName().c_str(), 0);
            paramfile = "";
        }
#endif
    return( paramfile );
}
//
// This writes the parameter file into the local directory
// Note: KiCad writes to C:\Users\Brian_17\AppData\Roaming\kicad\PCBNew, eeSchema, etc. parameter files
//  
void    WriteParameterFile( void )
{
std::string     parameters = "";

        parameters = ParameterList[0] + '=' + G_ProjectName.FullName() + '\n';
        parameters += ParameterList[1] + '=' + G_FrontPrefix + '\n';
        parameters += ParameterList[2] + '=' + std::to_string(G_RemoveFrontPrefix) + '\n';
        parameters += ParameterList[3] + '=' + G_BackPrefix + '\n';
        parameters += ParameterList[4] + '=' + std::to_string(G_RemoveBackPrefix) + '\n';
        parameters += ParameterList[5] + '=' + std::to_string(G_SortCode) + '\n';
        parameters += ParameterList[6] + '=' + std::to_string(G_FrontStartRefDes) + '\n';
        parameters += ParameterList[7] + '=' + std::to_string(G_BackStartRefDes) + '\n';
        parameters += ParameterList[8] + '=' + std::to_string(G_SortOnModules) + '\n';
        parameters += ParameterList[9] + '=' + std::to_string(G_SortGrid) + '\n';
        parameters += ParameterList[10] + '=' + std::to_string(G_WriteChangeFile) + '\n';
        parameters += ParameterList[11] + '=' + std::to_string(G_WriteLogFile) + '\n';
        parameters += ParameterList[12] + '=' + SizetoString(G_MainDialogSize) + '\n';

        FileName param;
        param = ParamFileName();
        WriteStringtoFile(ParamFileName(), parameters);
}   //WriteParameterFile()

//
// This loads the parameter file from the local directory and sets the values
//
void    LoadParameterFile(  )
{
std::string  paramline, buffer, parameter;
int     i, paramvalue;
size_t  newline = 0, delim;

        G_ProjectName = "";            //Set all defaults
        G_FrontPrefix.clear();
        G_BackPrefix.clear();
        G_RemoveFrontPrefix = false;
        G_RemoveBackPrefix = false;
        G_SortCode = 0;
        G_FrontStartRefDes = 1;
        G_BackStartRefDes = 0;
        G_SortOnModules = true;
        G_SortGrid = DEFAULT_GRID;
        G_WriteLogFile = false;
        G_WriteChangeFile = false;
        G_MainDialogSize = DEFAULTMAINDIALOG;           //Size of the main dialog

        FileName param;
        param = ParamFileName();
        LoadFileIntoString( buffer, param );    //Empty if not found
//
// Now i have the parameter file in buffer
//
        do          // Process a line at a time
        {
            PullLineIntoString( paramline, newline, buffer );   //Copy a string to a work buffer
            if (paramline.empty()) break;                  //Nothing more to do - break out of do
            TrimString( paramline );

            delim = paramline.find( '=' );                  //Find the =
            if( NPOS == delim )
            {
                ShowMessage( "Invalid Parameter File no = in %s ", paramline );
                break;
            }

            parameter = paramline.substr( delim + 1 );
            paramvalue = atoi( parameter.c_str());
            
            for( i = 0; !ParameterList[i].empty(); i++)  //Until the end of the list
            {
                if( 0 == paramline.find( ParameterList[i] ))      //found
                {    switch ( i )
                    {
                        case 0 : G_ProjectName = parameter; break;
                        case 1 : G_FrontPrefix = parameter;break;
                        case 2 : G_RemoveFrontPrefix = paramvalue; break;
                        case 3 : G_BackPrefix = parameter; break;
                        case 4 : G_RemoveBackPrefix = paramvalue; break;
                        case 5 : G_SortCode = paramvalue; break;
                        case 6 : G_FrontStartRefDes = paramvalue; break;
                        case 7 : G_BackStartRefDes = paramvalue; break;
                        case 8 : G_SortOnModules = paramvalue; break;
                        case 9 : G_SortGrid = fabs( atof( parameter.c_str())); break; //c++ stof blows up if not a valid float
                        case 10 : G_WriteChangeFile = paramvalue; break;
                        case 11 : G_WriteLogFile = paramvalue; break;
                        case 12 : G_MainDialogSize = StringtoSize( parameter, DEFAULTMAINDIALOG); break;

                        default :
                            ShowMessage( "Parameter %s invalid!\n ", parameter );
                            break;
                     }
                    break;  //Out of the for loop
                }
            }
        } while( true );

}

void    FileMessage(std::string message, FileName filename)
{
    std::string fullname;
    fullname = filename.FullName();
    ShowMessage(message.c_str(), fullname);
}

void    FileError(std::string message, FileName filename)
{
    std::string fullname;
    fullname = filename.FullName();
    FatalError( message.c_str(), fullname );
}
//
//Write the string to filename
//
void    WriteStringtoFile( FileName filename, std::string& buffer)
{
    std::ofstream tmphandle( filename.FullName(), std::ios::trunc); //Open the file for writing
    if (tmphandle.is_open()) tmphandle << buffer;           //Write the buffer
    if (!tmphandle.is_open() || tmphandle.bad())            //Error?
        FileError("Can't write %s\n", filename );
    FileMessage("%s updated \n", filename );
}
//
// Save the buffer to the filename
//
void    SaveKiCadFile( struct KiCadFile &kicadfile )
{
    if ( kicadfile.filename.Name.empty()) return;            //Nothing to do
    
FileName backupfile;
    
        backupfile = kicadfile.filename.FullName();
        backupfile.Extension = backupfile.Extension + (std::string) "_RenumBack";
        remove( backupfile.FullName().c_str() );      //Delete the old backup
        
        if ( 0!= rename(kicadfile.filename.FullName().c_str(), 
                                    backupfile.FullName().c_str( )))
            FileError("Can't create backup file for %s\n", kicadfile.filename );
        WriteStringtoFile( kicadfile.filename, kicadfile.buffer );
}  //Savekicadfile()


//
//  Write out the ChangeArray to KiCadChangeArray.txt
//
void    WriteChangeArray( void  )
{
std::string  outstring = "";
FileName    changearray;

        changearray = (std::string) CHANGEARRAYNAME;
        changearray.Directory = G_ProjectName.Directory;
        for( size_t i = 0; i < G_ChangeArray.size(); i++ )
            outstring = outstring + G_ChangeArray[i].OldRefDesString + ',' + G_ChangeArray[i].NewRefDes + '\n';
        WriteStringtoFile( changearray, outstring );
}

//
// This is where we usually leave: ensures the memory is freed up
//
void    WriteLogFile( void )
{
        if( !G_WriteLogFile ) return;
FileName    logfile;
        logfile = LOGFILENAME;
        logfile.Directory = G_ProjectName.Directory;
        WriteStringtoFile( logfile, G_LogFile );
}

void    NotFoundError( const char *errtype, std::string &refdes )
{
std::string  serrtype = errtype;
        ShowWarning( "***** New Reference for %s %s not found *****\n", serrtype, refdes );
        if( G_Errcount++ > 10 )
            FatalError("\n\nToo many errors - exiting ..." );     //I am out of here
}

//
//  Load a file into a std::string. This avoids malloc issues.
//
void        LoadFileIntoString( std::string& outbuffer, FileName& filename )
{
std::stringstream   buffer;

            FileMessage( "Loading %s \n", filename );

std::ifstream    readhandle(filename.FullName().c_str() );

            if( !readhandle.is_open())
                FatalError("LoadFile: File not found!\n" );
            else
            {
                buffer << readhandle.rdbuf();       //Read the file into the buffer
                outbuffer = buffer.str();           //Copy buffer into string
            }
}   //LoadFileIntoString()

//
// Find OldRefDes in the sorted change array using a binary search
//
int     FindNewRefDes( std::vector <RefDesChange> &ChangeArray, std::string& NewRefDes, const std::string& OldRefDes, bool& unannotated )    // Find it in the change array
{
size_t  start = 0, end = ChangeArray.size(), mid;

        if( 0 == end ) return( -1 );
        NewRefDes = OldRefDes;
        if(( '#' == OldRefDes[0] ) ||                 //If ignore (i.e. #)
                ( "\"\"" == OldRefDes ) ||            //Blank "" ref des ignore
                    ( '?' == OldRefDes.back()))
                        return( 0 );                //Unannotated

        if( !isdigit( OldRefDes.back()))        //If not a number last (i.e. Screw) do not change it
        {
            unannotated = false;
            return(0);
        }

        mid = ( start + end )/2;        //Start in the middle
        do
        {
            if( OldRefDes < ChangeArray[ mid ].OldRefDesString ) //In the lower half
                end = mid;
            else
                start = mid;
            mid = ( start + end )/2;
        } while(( end - start ) > 1 );                      //Until only 1 place left

        if( ChangeArray[ mid ].OldRefDesString == OldRefDes )   //Is this it?
        {
            unannotated = false;                            //Found it
            ChangeArray[ mid ].Found = true;                //Assume this is the new refdes
            if( ChangeArray[ mid ].Ignore ) return( 0 );    //Oops supposed to ignore
#ifdef _NOCHANGES
//Use for debug: replaces old with old so you can use file compare to verify file isn't trashed
#else
            NewRefDes = ChangeArray[ mid ].NewRefDes;       //This is the new refdes

#endif
            return( 0 );                                    //All good
        }
        else
            return( - 1 );
}


void    AddFileToSchematic( std::vector  <KiCadFile> &AllSchematics, FileName& filename )
{
KiCadFile   NewEntry;

        NewEntry.filename = filename;
        NewEntry.filename.Extension = "sch";
        NewEntry.filename.Directory = G_ProjectName.Directory;
        NewEntry.scanned = false;
        for( size_t it = 0; it < AllSchematics.size(); it++ ) //See if already have it
           if( AllSchematics[it].filename.FullName() == 
                        NewEntry.filename.FullName() ) return;      //Already have the file in the array so do nothing

        AllSchematics.push_back( NewEntry );                        //Add the file name to the list
        LoadFileIntoString(AllSchematics.back().buffer, 
                                    AllSchematics.back().filename);    //Load the file
} //AddFileToSchematic

//
// Build up the list of schematic file names and load into buffers as strings
//
//$Sheet
//F1 "NAND Flash , eMMC, T-Card and Audio.sch" 60
//$EndSheet
//
void    FlattenSchematic( void )
{
struct  KiCadFile   OneSheet;
size_t i;
std::string  fieldline;
size_t      firstquote, secondquote, wheresheet, whereendsheet;
bool        foundfilename;
FileName    filename;

        G_AllSchematics.clear();
        AddFileToSchematic( G_AllSchematics, G_ProjectName );   //Start the process

        for( i = 0; i < G_AllSchematics.size(); i++ ) 
        {
            if(G_AllSchematics[i].scanned ) continue;           //Already checked
            G_AllSchematics[i].scanned = true;                   //Now I did
            wheresheet = 0;
            whereendsheet = 0;
            do
            {   //Look for F1 at beginning of line (Filename)
                foundfilename = false;
                wheresheet = G_AllSchematics[i].buffer.find("$Sheet", whereendsheet );         //Find where it ends
                if( NPOS == wheresheet ) break;                                                 //No sheets left in this schematic
                whereendsheet = G_AllSchematics[i].buffer.find("$EndSheet", wheresheet );         //Find where it ends
                do
                {
                    PullLineIntoString( fieldline, wheresheet, G_AllSchematics[i].buffer );       //Copy just a line
                    if( 0 != fieldline.find("F1 ")) continue;   //If F1 not the beginning try next
                    firstquote = fieldline.find('\"' ) + 1;
                    secondquote = fieldline.find('\"', firstquote );
                    filename = fieldline.substr(firstquote, secondquote - firstquote);
                    AddFileToSchematic( G_AllSchematics, filename );  //Add this file to the list
                    foundfilename = true;
                } while( wheresheet < whereendsheet );
                if (!foundfilename)
                {
                    std::string fname = G_AllSchematics[i].filename.FullName();
                    ShowWarning("Warning bad $Sheet in file %s\n", fname);
                }
            } while (true);
        }
} //FlattenSchematic

//
// Pull a line into a std::string from a std::string, adjust pointer to next line
//
void    PullLineIntoString( std::string& dest, size_t& newline, const std::string& source )
{
        dest.clear();
        newline = source.find_first_not_of( "\n\r ", newline );  //Go to not CRLF or space
        if( NPOS == newline ) return;    //Not found
size_t  nextline = source.find_first_of( "\n\r", newline );            //Find newline
        nextline = source.find_first_not_of( "\n\r", nextline );       //Get end of line
        dest = source.substr( newline, NPOS == nextline ? NPOS : nextline - newline );
        newline = nextline;
}

//
//  Locate a field with text SearchFor and find the starting '"'
//  Append to dest up and including the quote
//  Copy the quoted test into fieldptr
//  Return pointer to the last '"'
//
void    CopyCompField( std::string& field, std::string& aline,
                       size_t& fieldstart, size_t& fieldend, const std::string& startdelim, const std::string& enddelim )
{
    fieldstart = aline.find( startdelim ) + startdelim.size();
    fieldend = aline.find( enddelim, fieldstart + 1 ) ;

    field = aline.substr( fieldstart, fieldend - fieldstart );
}

//
//  Trim leading and trailing spaces from a std::string
//
void    TrimString( std::string& input )
{
    while(( input[0] <= ' ') && (!input.empty())) input.erase(0);   //Deal with the leading non-printables
    while(( input[input.size() - 1] <= ' ' ) && (!input.empty())) input.resize(input.size() - 1);    //Trim trailing non printables
}

void    GetParenDelimitedField( std::string& outfield, const std::string& inbuf, const size_t& fieldstart )
{
    size_t  i = fieldstart, bracketcount = 0;
    do{
        if( '(' == inbuf[i] ) ++bracketcount;
        if( ')' == inbuf[i++] ) --bracketcount;
    }while ( 0 != bracketcount );

    outfield = inbuf.substr( fieldstart, i - fieldstart );
}

//
// aline points to a std::string buffer, field is the field to get the cordinate of, i.e. "(at "
// startcood is the start point for the search, endcoord
//
//  return false if no field present
//
bool    GetXY( const std::string &buffer, const char *field, size_t &startcoord, size_t &endcoord, double &xcoord, double &ycoord )
{
    startcoord = buffer.find( field, startcoord ) + strlen( field );  //Get Module X coordinate
    if( NPOS == startcoord ) return( false );       //No field

    endcoord = buffer.find( ' ', startcoord );      //Get X coordinate
    xcoord = atof( buffer.substr( startcoord, endcoord - startcoord ).c_str() );
    startcoord = buffer.find(' ', endcoord );       //Get Y coordinate
    endcoord = buffer.find_first_of( " )", startcoord + 1 );    //Space if an angle, otherwise )
    ycoord = atof( buffer.substr( startcoord + 1, endcoord - startcoord ).c_str() );

    return ( true );
}

bool    GetXY( const std::string &buffer, const char *field, size_t &startcoord, size_t &endcoord, std::string &xcoord, std::string &ycoord )
{
    startcoord = buffer.find( field, startcoord );
    if( NPOS == startcoord ) return( false );   //No field
    startcoord += strlen( field );              //Get X coordinate

    endcoord = buffer.find( ' ', startcoord );
    xcoord = buffer.substr( startcoord, endcoord - startcoord );

    startcoord = buffer.find(' ', endcoord );                   //Get Y coordinate
    endcoord = buffer.find_first_of( " )", startcoord + 1 );    //Space if an angle, otherwise )
    ycoord = buffer.substr( startcoord + 1, endcoord - startcoord - 1);

    return ( true );
}

bool    GetXYandAngle( const std::string &buffer, const char *field, size_t &startcoord, size_t &endcoord, double &xcoord, double &ycoord, double &angle )
{
    if( !GetXY( buffer, field, startcoord, endcoord, xcoord, ycoord ) ) return( false ); //field not found
    startcoord = endcoord;
    endcoord = buffer.find(')', startcoord );          //Get X,Y coordinate

    if( ')' == buffer[startcoord] )   //If no angle
        angle = 0.0;
    else
        angle = atof( buffer.substr( startcoord + 1, endcoord - startcoord ).c_str() );
    return( true );
}

bool    GetXYandAngle( const std::string &buffer, const char *field, size_t &startcoord, size_t &endcoord, std::string &xcoord, std::string &ycoord, std::string &angle )
{
    if( !GetXY( buffer, field, startcoord, endcoord, xcoord, ycoord ) ) return( false ); //field not found
    startcoord = endcoord;
    endcoord = buffer.find(')', startcoord );          //Get X,Y coordinate

    if( ')' == buffer[startcoord] )   //If no angle
        angle.clear();
    else
        angle = buffer.substr( startcoord + 1, endcoord - startcoord );
    return( true );
}

//
// Load the PCB file
//
int     LoadPCBFile( struct KiCadFile &PCBFile )
{
struct stat buf;
std::string dir, name, ext;

        if (0 != stat( G_ProjectName.FullName().c_str() , &buf))  return(-1);                      //Invalid file name
        PCBFile.buffer.clear();     //Start with nothing
        PCBFile.filename = G_ProjectName;
        PCBFile.filename.Extension = "kicad_pcb";           //Figure out the PCB file name
        LoadFileIntoString( PCBFile.buffer, PCBFile.filename );                //Load this file and extension, get file size
        if( 0 == PCBFile.buffer.size() ) return ( -1 ); //No gots

size_t  modulecount = PCBFile.buffer.find("(modules ");                                  //Find out how many modules there are
        if( NPOS == modulecount )
            FatalError("No modules count in file!" );

        G_Modules = atoi(PCBFile.buffer.substr( modulecount + sizeof("(modules")).c_str());

size_t  starttxt = PCBFile.buffer.find( "(layers" );     //Get the Front layer text name (always layer 0)
        if( NPOS == starttxt )
            FatalError("No layers field in PCB file!" );

        starttxt = PCBFile.buffer.find( "(0 ", starttxt + sizeof("(layers") );                //find next (
        starttxt += sizeof("(0");
size_t  endtxt = PCBFile.buffer.find(' ', starttxt );
        G_FrontLayerName = PCBFile.buffer.substr( starttxt, endtxt - starttxt );             //Get the Front layer name

        return( 0 );
}

void    GetField( std::string &dest, const char *fieldname, std::string &instr, size_t &pointer, char enddelim )
{
std::string  tmpfield;

        tmpfield.append( fieldname );
        tmpfield += ' ';
        pointer = instr.find( tmpfield, pointer );

        if( NPOS != pointer )           //Field found
        {
            pointer += tmpfield.size();  //Point to the text name
            dest = instr.substr( pointer, instr.find( enddelim, pointer ) - pointer ); //Get the text name
        }
}


void    UpdateProjectRefDes( bool messages )
{
        UpdatePCBRefDes( G_PCBInputFile, messages );               //Update the PCB ref des
        for( int i = 0; i < (int) G_AllSchematics.size(); i++)
            UpdateSchematicFileRefDes( G_AllSchematics[i], messages );
        FileName    netfilename;
        G_Netlist.filename = G_ProjectName;
        G_Netlist.filename.Extension = "net";
        UpdateNetlistRefDes( G_Netlist, messages  );                            //Now update the netlist names
}

//
//  Update all the nets and modules in the PCB
//
void    UpdatePCBRefDes( struct KiCadFile &PCBFile, bool messages )
{
bool    unannotated;        //Dummy
size_t  netptr = 0, inbufptr = 0, modptr, oldrefptr ;
std::string  TMPbuffer, NewRefDes, OldRefDes, Module;

        TMPbuffer.clear();
        if( messages ) FileMessage( "Updating %s\n", PCBFile.filename );  //Put this here to separate from log files

        while( NPOS != netptr ) //Until no more
        {
            netptr = PCBFile.buffer.find("\"Net-(", inbufptr ); //look for a net
            if( NPOS == netptr ) break;                     //No more nets just write out the remainder
            netptr += sizeof( "\"Net-(") - 1;
            TMPbuffer += PCBFile.buffer.substr( inbufptr, netptr  - inbufptr );      //Write out to here

            OldRefDes = PCBFile.buffer.substr( netptr, PCBFile.buffer.find( '-', netptr ) - netptr );
            if( 0 != FindNewRefDes( G_ChangeArray, NewRefDes, OldRefDes, unannotated ))    // Find it in the change array
                NotFoundError( "net", NewRefDes );

            TMPbuffer += NewRefDes;     //Write out the new refdes (if not found is old ref des
            inbufptr = netptr + OldRefDes.size() + sizeof('-') - 1;             //Skip over the old refdes, rince and repeat
        }
        TMPbuffer += PCBFile.buffer.substr( inbufptr );         //Write out the rest of it
//
//  Now do modules. Do this differently (a module at a time ) to handle text changes later
//
        PCBFile.buffer.clear();                                  //Write out from scratch to PCB buffer
        inbufptr = 0;
        modptr = 0;

        while( NPOS != modptr ) //Until no more
        {
            modptr = TMPbuffer.find("(module ", inbufptr );     //look for a module
            if( NPOS == modptr ) break;                         //No more modules just write out the remainder
            PCBFile.buffer += TMPbuffer.substr( inbufptr, modptr  - inbufptr );      //Write out to "(module "
            GetParenDelimitedField( Module, TMPbuffer , modptr );          //Module now has the isolated module (do this for text changes)
            inbufptr = modptr + Module.size();                            //Pick up after here for next module

            oldrefptr = Module.find( "fp_text reference " ) + sizeof( "fp_text reference ") - 1;  //Point to the old ref des
            OldRefDes = Module.substr( oldrefptr, Module.find( ' ', oldrefptr ) - oldrefptr );

            if( 0 != FindNewRefDes( G_ChangeArray, NewRefDes, OldRefDes, unannotated ))
                NotFoundError( "module", NewRefDes );

            else
                Module.replace( oldrefptr, OldRefDes.size(), NewRefDes );         //Replace the old with the new

            PCBFile.buffer += Module;                        //Write out the new module
        } //While
        PCBFile.buffer+= TMPbuffer.substr( inbufptr );         //Write out the rest of it
        return;
}

//
//  Scan through the Schematic file and substitute RefDes Old for RefDes New
//  The input file name has already been determined by the hierarchy scan so no need to add .sch
//  The new file is buffered in FileList.buffer
//
void    UpdateSchematicFileRefDes( struct KiCadFile &Schematic, bool messages )
{
bool        unannotated = true, err_report = true;
int         foundcmp;
size_t      nextcomp = 0, compend = 0;            //Use this to find where the next module starts
size_t      newline = 0, OldRefDesStart = 0, OldRefDesEnd = 0;
std::string  compfield;
std::string  aline, OldRefDes, NewRefDes, errfield;
std::string  outbuffer = "";

        if( messages ) FileMessage( "Updating %s\n", Schematic.filename ); //Put this here to separate from log files

        do    //Scan through the buffer (PCBFile) and replace old refdes with new ones.
        {
            nextcomp = Schematic.buffer.find("$Comp", compend );                          //Find the next component
            if( NPOS == nextcomp ) break;
            outbuffer  += Schematic.buffer.substr( compend, nextcomp - compend );          //Write out to after $EndComp
            compend = Schematic.buffer.find("$EndComp", nextcomp ) + sizeof("$EndComp" );  //Look for the $EndComp
            compfield = Schematic.buffer.substr( nextcomp, compend - nextcomp );           //Get the $Comp ... $EndComp
            newline = 0;
            PullLineIntoString( aline, newline, compfield );                        //Do a line at a time

            while( !aline.empty())
            {
                OldRefDes.clear();
                if( 0 == aline.find("L ")) //Is this the first line? (ie. L LED D201 )
                {
                    OldRefDesStart = aline.rfind(' ') + 1;       //Go to second space
                    OldRefDesEnd = aline.find_first_of( "\r\n", OldRefDesStart );
                    OldRefDes = aline.substr( OldRefDesStart );       //Get the comp field
                    TrimString( OldRefDes );
                }

                else if ( 0 == aline.find("AR") )
                    CopyCompField( OldRefDes, aline, OldRefDesStart, OldRefDesEnd, "Ref=\"", "\"" ); //Field from Ref=" to "

                else if ( 0 == aline.find("F 0") )
                    CopyCompField( OldRefDes, aline, OldRefDesStart, OldRefDesEnd, "\"", "\"" );    //Field from first " to "

                if( OldRefDes.empty())
                    outbuffer += aline;                      //Just write out the line
                else
                {   //Find the component and copy it to NewRefDes
                    foundcmp = 0;               //Assume found
                    if( '#' == OldRefDes[0]) unannotated = false;                       //Do not annotate
                    if( '?' == OldRefDes.back()) foundcmp = 1;                          //Un annotated component or AR field mismatch

                    foundcmp = FindNewRefDes( G_ChangeArray, NewRefDes, OldRefDes, unannotated );

                    if( err_report && ( -1 == foundcmp ))                             //Not found in change array
                    {
                        err_report = false;     //Once per component
                        NotFoundError( "schematic component", NewRefDes );
                    }
                    errfield = OldRefDes;
                    outbuffer += aline.substr( 0, OldRefDesStart ) + NewRefDes + aline.substr( OldRefDesEnd );
              }
                PullLineIntoString( aline, newline, compfield );
                if( NPOS == newline ) { outbuffer += aline; break;}
            }

            if( true == unannotated )
                ShowWarning( "**** Warning unannotated component %s! ****\n", errfield );

        }while( true );// while
        outbuffer += Schematic.buffer.substr( compend );                    //Write out to after $EndComp
        Schematic.buffer = outbuffer;                                //Update it
        return;
} //UpdateSchematicFileRefDes()


//
//  Scan through the Netlist file and substitute RefDes Old for RefDes New
//  Netlist update is simple Nets are all like this (ref C18)
//  So if the new ref des is C123 I replace C18 with C123
//
void    UpdateNetlistRefDes( struct KiCadFile &NetList, bool messages )
{
bool        unannotated;
size_t      nextnet, endparen;
std::string outnetlist, oldrefdes, NewRefDes, tmp;
struct stat buf;

        if( 0 != stat( G_Netlist.filename.FullName().c_str(), &buf)) //File not found
        {
            NetList.filename = "";       //Don't try again
            return;
        }
        if( messages ) FileMessage( "Updating %s\n", G_Netlist.filename );               //Put this here to separate from log files

        LoadFileIntoString( NetList.buffer, G_Netlist.filename);
        nextnet = NetList.buffer.find("(ref ");             //Use this to find where the ref name
        endparen = 0;

        while( nextnet != NPOS )              //Scan through the buffer and replace old refdes with new ones.
        {
            nextnet += + sizeof("(ref");               //copy to after the ref
            outnetlist += NetList.buffer.substr( endparen, nextnet - endparen );   //Copy from ")" to after "(ref "
            endparen = NetList.buffer.find( ')', nextnet );

            if( NPOS == endparen )                       //Not found
                FatalError("Invalid net list format!" );

            oldrefdes = NetList.buffer.substr( nextnet, endparen - nextnet );

            if( -1 == FindNewRefDes( G_ChangeArray, NewRefDes, oldrefdes, unannotated )) // Find it in the change array
                ShowWarning( "\n****** Warning net %s not found in net list change list\n", oldrefdes );

            outnetlist += NewRefDes;
            nextnet = NetList.buffer.find("(ref ", endparen );             //Use this to find where the ref name
            }
        outnetlist += NetList.buffer.substr( endparen );        //Copy from last ")" to the end
        NetList.buffer = outnetlist;
} //UpdateNetlistRefDes()

//
// Routines to produce formatted output for logging
//
std::string  FloatFormat( double anum, int decimal )
{
std::string  outs = std::to_string( anum ); //Gives 6 decimal places
        outs.resize( outs.find('.') + 1 + ( decimal > 6 ? 6 : decimal ));
        return( outs );
}

//
//  Make nice with tabs
//
void    LogLineItUp(  std::string text, int tab  )
{
    text.resize( tab, ' ');
    G_LogFile += text;
}

//
//  This is where all the magic happens
//
void    RenumKiCadPCB(void)
{
int i, num;
std::vector     <RefDesChange> PrefixChangeArray;

    PrefixChangeArray.clear();
    G_LogFile.clear();          //Since I can do multiple runs, clear all the globals.
    G_Errcount = 0;
    if( G_SortGrid < MINGRID ) G_SortGrid = MINGRID;  //Make sure sort grid is > 0

    FlattenSchematic(  );
    ShowMessage( "The schematic has %d unique sheet(s).\n", ((int) G_AllSchematics.size()));
//
// If adding or removing prefixes, need to process those first
// 
    LoadModuleArray(G_PCBInputFile.buffer);           //Load the module array, split into Front and Back

    if( G_RemoveFrontPrefix || G_RemoveBackPrefix || !G_FrontPrefix.empty() || !G_BackPrefix.empty() )
    {
        MakePrefixChangeArray( G_FrontModules, G_RemoveFrontPrefix, G_FrontPrefix  );             //Make a fake change array
        MakePrefixChangeArray( G_BackModules, G_RemoveBackPrefix, G_BackPrefix  );
        if( G_WriteLogFile ) LogChangeArray( (char *) "\nPrefix modification plan\n" );
//
// I don't have to update the actual files: I can simply update the Change Array
//


//        UpdateProjectRefDes( NOMESSAGES );                   //Update the PCB file, schematics, and netlist (if present)
        PrefixChangeArray = G_ChangeArray;
        LoadModuleArray(G_PCBInputFile.buffer);       //reload the module array, split into Front and Back
    }
//
//  Now do the sorting
//
    if(  0 != MakeChangeArray(  )) //Trying to start with back ref des < end start refdes and no prefix
            return;
    if( G_WriteLogFile ) LogChangeArray( (char *) "\nRenumbering Plan\n" );
    UpdateProjectRefDes( MESSAGES );                          //Update the PCB file, schematics, and netlist (if present)
//
// All the file processing is done. If there are errors, ask to commit.
//      If no errors or OK to commit, create backup files for all the file names and write out the new files
//
    if( 0 != G_Errcount )     //If there were errors
    {
//        ShowError( "\n**** Warning: %d errors in files ****\n", G_Errcount );
ContinueAbort  TmpContinueAbort( NULL, wxID_ANY, wxT(""), 
                    wxDefaultPosition, AdjustItemSize(400,300));      //Show Continue/Abort menu
                        TmpContinueAbort.ShowModal();                //I should sFront until clicked: Contine sets G_Errcount to 0
    }

    if (0 != G_Errcount)      //If errors or abort
    {
        G_PCBInputFile.buffer.clear();          //Force reload of the original files.
        G_LogFile += "Aborted due to errors ";
    }
    else
    {
        ShowMessage("Making backups ... \n");
        ShowMessage("Writing files ... \n");
        SaveKiCadFile(G_PCBInputFile);        //Save the PCB file

        for (i = 0; i < (int)G_AllSchematics.size(); i++)  //Save each schematic
            SaveKiCadFile(G_AllSchematics[i]);
        SaveKiCadFile(G_Netlist);                 //Save the netlist

        num = PrefixChangeArray.size();
        if (0 != num)       //If I did prefixes
        {
            bool        dummy;
            std::string NewRefDes;

            if (num != (int)G_ChangeArray.size()) FatalError("Miss-match on prefix, renumber change array ");
            for (i = 0; i < num; i++)       //Merge the two arrays
            {
                FindNewRefDes(G_ChangeArray, NewRefDes, PrefixChangeArray[i].NewRefDes, dummy);    // Find it in the change array
                PrefixChangeArray[i].NewRefDes = NewRefDes;
            }
            G_ChangeArray = PrefixChangeArray;
        }
        WriteChangeArray();
    }
    WriteLogFile( );        //Write out the log file
}//RenumKiCadPCB

//
//If making a log file, show your work
//
void   LogModuleArray( std::vector <PCBModule> &PCBModules )
{
size_t  i, modules = PCBModules.size();
        G_LogFile += "\n*********** Sort on " +
                        (std::string)( G_SortOnModules ? "Ref Des" : "Module" )
                                +  " Coordinates *******************";
        for( i = 0; i < modules; i++ )
        {
                std::string layer;
                layer = PCBModules[i].layer;
                LogLineItUp( "\n" + std::to_string( i ), 10  );
                LogLineItUp( PCBModules[i].RefDesString, 20  );       //Ref des
                LogLineItUp( layer, 4  );               //The side
                LogLineItUp( FloatFormat( PCBModules[i].oldx, 3 ), 12 );                //Old X coordinate
                LogLineItUp( FloatFormat( PCBModules[i].oldy, 3 ), 12 );                //Old Y coordinate
                LogLineItUp( FloatFormat( PCBModules[i].x, 3 ), 12 );       //Old X coordinate
                LogLineItUp( FloatFormat( PCBModules[i].y, 3 ), 12 );       //Old Y coordinate
        }
} //LogModuleArray

//
// Load the modules, split into Front and Back and create the RefDesTypeArray
//
int     LoadModuleArray( std::string &PCBBuffer )                     //Load up the module array
{
double  ModXCoord, ModYCoord;   //What the X and Y Coordinate of the module is
double  rounder;                //Used to round to grid
size_t  starttxt = 0, endtxt;
int     i = 0, k;
int     blankcount = 0;

PCBModule   module;
RefDesTypeStruct  refdestype;

        G_RefDesTypes.clear();
        G_ChangeArray.clear();
        G_FrontModules.clear();
        G_BackModules.clear();                //Start fresh
        do
        {
            starttxt = PCBBuffer.find( "(module ", starttxt );  //Use this to find where the next module starts
            if( NPOS == starttxt ) break;
            module.ModuleIndex = starttxt + (sizeof("(module"));    //Where the Module is in the PCB

            starttxt = PCBBuffer.find("(layer ", starttxt ) + sizeof( "(layer");
            endtxt = PCBBuffer.find( ')', starttxt );

            module.layer = 'F';
            if( G_FrontLayerName != PCBBuffer.substr( starttxt, endtxt - starttxt )) //If not the Front layer it is the
                module.layer = 'B';           //Back layer

            GetXY( PCBBuffer, "(at ", starttxt, endtxt, module.x, module.y );
            starttxt = PCBBuffer.find("(fp_text reference ",starttxt ) + sizeof( "(fp_text reference");
            endtxt = PCBBuffer.find(' ', starttxt );

            module.RefDesIndex = starttxt + (sizeof("((fp_text reference"));    //Where the reference designator is
            module.RefDesString = PCBBuffer.substr( starttxt, endtxt - starttxt );   //Get the ref des;

            if(( "\"\"" == module.RefDesString ) || ( 0 == module.RefDesString.size() ))   //Ignore zero length ref des
            {   ++blankcount;
                continue;
            }
            GetXY( PCBBuffer, "(at ", starttxt, endtxt, ModXCoord, ModYCoord );
            if( !G_SortOnModules ) //Only if sorting by reference designator coordinate
            {
                module.x += ModXCoord;
                module.y += ModYCoord;
            }

            module.oldx = module.x;
            module.oldy = module.y;

            rounder = fmod( module.x , G_SortGrid);
            module.x -= rounder;                                     //X coordinate down to grid
            if( rounder > ( module.x/2 )) module.x += G_SortGrid;    //Round X coordinate up to grid

            rounder = fmod( module.y , G_SortGrid);
            module.y -= rounder;                                     //X coordinate down to grid
            if( rounder > ( module.y/2 )) module.y += G_SortGrid;    //Round X coordinate up to grid

            for( k = (int) module.RefDesString.size() - 1; k >= 0; k-- )    //Go from end to start looking for non-digit
                if( !isdigit( module.RefDesString[k] )) break;              //Allows for B1_nn ref des

            if( k >= 0 ) refdestype.RefDesType = module.RefDesString.substr( 0, k + 1 );             //Get just the name (i.e. U)

            module.RefDesNumber = strtoul( module.RefDesString.substr( k + 1 ).c_str(), NULL, 0);
            module.RefDesType = refdestype.RefDesType;
            refdestype.RefDesCount = 0;

            for( k = 0; k < (int) G_RefDesTypes.size(); k++ )                           //Search for this ref des type
                if( refdestype.RefDesType == G_RefDesTypes[ k ].RefDesType ) break;     //Already have this one

            refdestype.RefDesCount = 0;
            if( k == (int) G_RefDesTypes.size() )                       //A new type!
                G_RefDesTypes.push_back( refdestype );                  //Add this to the list

             if( 'F' == module.layer )
                G_FrontModules.push_back( module );
            else
                G_BackModules.push_back( module );
        }while( ++i < G_Modules );

        if(( i ) != G_Modules )
            FatalError( "Error: PCB modules does not match declaration\n" );

        if (G_WriteLogFile)
        {
            LogModuleArray(G_FrontModules);
            LogModuleArray(G_BackModules);
        }
        ShowMessage("There are %d modules on Front ", G_FrontModules.size());
        ShowMessage("%d modules on Back.", G_BackModules.size());
        ShowMessage("There are %d modules with no ref des\n", blankcount );
        return( 0 );
}

//
// Use std::sort() to sort modules. Because it is a structure a compare function is needed
// Returns true if the first coordinate should be before the second coordinate
//
static bool ModuleCompare(const PCBModule &A, const PCBModule  &B )
{
double   X0 = A.x, X1 = B.x, Y0 = A.y, Y1 = B.y;
double   tmp;

        if( G_SortYFirst )  //If sorting by Y then X, swap X and Y
        {   tmp = X0; X0 = Y0; Y0 = tmp;
            tmp = X1; X1 = Y1; Y1 = tmp;
        }

        if( G_DescendingFirst ) { tmp = X0; X0 = X1; X1 = tmp; } //If descending, same compare just swap directions
        if( G_DescendingSecond  ) { tmp = Y0; Y0 = Y1; Y1 = tmp; }

        if( X0 < X1 ) return( true );               //yes, its smaller
        if( X0 > X1 ) return( false );              //No its not
        if( Y0 < Y1 ) return( true );               //same but equal
        return( false );
}

//
//Create a change array from a module list
//
void    PCBSortSide( std::vector <PCBModule > &ModuleArray, int SortCode, unsigned int StartRefDes, 
                                    unsigned int &MaxRefDes, std::string &MaxRefDesName )
{
size_t  errcnt = 0;
std::vector <PCBModule>::iterator ModuleIterator;
std::vector < RefDesTypeStruct>::iterator TypesIterator;
std::vector <RefDesTypeStruct>::iterator ChangeIterator;
struct  RefDesChange    Change;

        MaxRefDes = 0;          //Start with nothing
//
// First sort the module array
//
        G_SortYFirst = (( SortCode & SORTYFIRST ) != 0 );     //If sorting by Y then X, swap X and Y
        G_DescendingFirst = (( SortCode & DESCENDINGFIRST ) != 0 );    //If descending, same compare just swap directions
        G_DescendingSecond = (( SortCode & DESCENDINGSECOND ) != 0 );    //If descending, same compare just swap directions
        sort( ModuleArray.begin(), ModuleArray.end(), ModuleCompare );

        if (0 != StartRefDes)      //If I am not carrying on from the other side, reinit change array
        {     //set the starting reference designation for this side
            for (ChangeIterator = G_RefDesTypes.begin();
                ChangeIterator != G_RefDesTypes.end();
                ChangeIterator++)
                ChangeIterator->RefDesCount = StartRefDes;
        }

        for (ModuleIterator = ModuleArray.begin();      // Now make the change array from the sorted modules
                ModuleIterator != ModuleArray.end();
                    ModuleIterator++ )                 //For each module/change array
        {
            for (TypesIterator = G_RefDesTypes.begin();
                    TypesIterator != G_RefDesTypes.end();
                        TypesIterator++) //Look in the types array
            {
             if( ModuleIterator->RefDesType == TypesIterator->RefDesType )         //I found the type (U, R, VR, etc )
             {
                 Change.Ignore = !isdigit(ModuleIterator->RefDesString.back());     //Ignore if no digit at end
                 if (TypesIterator->RefDesCount > MaxRefDes)        //Finds the maximum ref des on this side
                 {
                     MaxRefDes = TypesIterator->RefDesCount;
                     MaxRefDesName = ModuleIterator->RefDesString;      //And its name
                 }
                 Change.NewRefDes = TypesIterator->RefDesType + std::to_string(TypesIterator->RefDesCount++);   //Make the new refdes
                 Change.OldRefDesString = ModuleIterator->RefDesString;              //Remember the original for look up
                 Change.Found = 0;                                                  //Hasn't been found
                 if( Change.Ignore ) Change.NewRefDes = Change.OldRefDesString;     //Don't modify if ignore
                 G_ChangeArray.push_back( Change );                                 //Add this module to the change Array
                 break;
            }
        }

        if((TypesIterator == G_RefDesTypes.end()) && ( errcnt ++ < 10 ))   //Show max 10 error per sheet
        {
            ShowWarning( "\nError %d RefDes ", errcnt );
            ShowWarning( "%s not found! ", ModuleIterator->RefDesType );

            if( G_WriteLogFile )        //Show errors in log file
            {
                G_LogFile += Change.OldRefDesString + "->" + Change.NewRefDes + '\n';
                G_LogFile += "\nError " + std::to_string( errcnt );
                G_LogFile += ModuleIterator->RefDesType + " not found!";
            }
        }
    }
    G_Errcount += errcnt;
}

void    LogChangeArray( char * message )
{
std::vector <RefDesChange>::iterator ChangeIterator;
        G_LogFile += message;
        for(ChangeIterator = G_ChangeArray.begin();
                ChangeIterator != G_ChangeArray.end();
                    ChangeIterator++ )
        {
            G_LogFile += ChangeIterator->OldRefDesString 
                            + "->" + ChangeIterator->NewRefDes + '\n';
        }
}

//
// Used for sorting the change array
//
static  bool    ChangeCompare( const RefDesChange& A, const RefDesChange& B )
{
        return( A.OldRefDesString < B.OldRefDesString );
}

//
// Make a sorted ChangeArray
//
int     MakeChangeArray( void )
{
int     k = 0;
size_t  i = 0;

std::string     MaxRefDesName;
unsigned int    MaxRefDes;

        if( G_WriteLogFile )
        {
            G_LogFile += "\n\nReference Designator Change Plan\n";
            G_LogFile += "\n\nThere are " + std::to_string(G_RefDesTypes.size()) + " types of reference designations";

            for (i = 0; i < G_RefDesTypes.size(); i++)
            {
                if (0 == (k++) % 8) G_LogFile += "\n";              //On a new line
                LogLineItUp(G_RefDesTypes[i].RefDesType, 10);   //Pad spaces
            }
        }
        PCBSortSide( G_FrontModules, G_FrontDirectionsArray[G_SortCode], G_FrontStartRefDes, MaxRefDes, MaxRefDesName );        //Sort the Front reference designations, then the Back ones
//
// If I am not continuing from the Front and I have a Back prefix and I'm not removing it
// check if the last Front ref des is greater less than or equal to the Back start ref des
//
        if ((0 != G_BackStartRefDes)                        //If not continuing from the front
            && ((MaxRefDes >= G_BackStartRefDes)            //There may be a problem 
                && (((G_BackPrefix.empty() )                //If no prefix an error 
                    || (!G_BackPrefix.empty() && G_RemoveBackPrefix))))) //If removing prefix have an error
            {
                ShowWarning("\n**** Error: Front Layer highest ref des  is %s. ****\n", MaxRefDesName );
                ShowWarning("**** Starting Back layer ref des number must be greater than %d ****\n", MaxRefDes );
                MaxRefDesName = "Change Back Ref Des Start to 0 or > " + std::to_string(MaxRefDes) + " and try again!";
                Abort       TmpAbort(NULL, wxID_ANY, MaxRefDesName.c_str(),
                    wxDefaultPosition, AdjustItemSize(450, 100));      //Show Continue/Abort menu
                TmpAbort.ShowModal();                //I should sFront until clicked: Contine sets G_Errcount to 0
                return(-1);
            }   //Make the change array

        PCBSortSide( G_BackModules, G_BackDirectionsArray[G_SortCode], G_BackStartRefDes, MaxRefDes, MaxRefDesName );
        sort( G_ChangeArray.begin(), G_ChangeArray.end(), ChangeCompare );  //Now sort the Modules by old ref des to speed up look ups
        return(0);      //OK
} //int     MakeChangeArray( void )


void    MakePrefixChangeArray( std::vector <PCBModule > &ModuleArray, bool RemovePrefix, std::string& Prefix  )
{
bool    haveprefix;
int     prefixsize = Prefix.size();
std::vector< PCBModule>::iterator ModuleIterator;

struct  RefDesChange    Change;

        for(ModuleIterator = ModuleArray.begin(); 
                ModuleIterator != ModuleArray.end(); 
                    ModuleIterator++)   //For each module/change array
        {
            Change.Ignore = !isdigit( ModuleIterator->RefDesString.back());      //Ignore if no digit at end
            Change.OldRefDesString = ModuleIterator->RefDesString;               //Remember the original for look up
            Change.NewRefDes = Change.OldRefDesString;                          //Assume no change
            Change.Found = false;
            if(( !Change.Ignore ) || ( 0 != prefixsize ))                       //If a change in prefix (going to add it or remove it
            {
                haveprefix = ( 0 == ModuleIterator->RefDesString.find( Prefix ));
                if( haveprefix && RemovePrefix )
                    Change.NewRefDes = ModuleIterator->RefDesType.substr( Prefix.size()) 
                        + std::to_string(ModuleIterator->RefDesNumber + BIGGEST_REFDES );
                else if( !haveprefix && !RemovePrefix )
                    Change.NewRefDes = Prefix + ModuleIterator->RefDesType + 
                                std::to_string(ModuleIterator->RefDesNumber + BIGGEST_REFDES );
            }
            G_ChangeArray.push_back( Change );                                 //Add this module to the change Array
        }
        sort( G_ChangeArray.begin(), G_ChangeArray.end(), ChangeCompare );  //Now sort the Modules by old ref des to speed up look ups
}

//
// Routines to produce formatted output for logging
//
std::string  FloatFormat( float anum, int decimal )
{
std::string  outs = std::to_string( anum ); //Gives 6 decimal places
        outs.resize( outs.find('.') + 1 + ( decimal > 6 ? 6 : decimal ));
        return( outs );
}



/*
 *  the end
 */
