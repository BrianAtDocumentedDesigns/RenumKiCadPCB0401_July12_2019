///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Oct 26 2018)
// http://www.wxformbuilder.org/
//
// PLEASE DO *NOT* EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "RenumKicadPCB_Base.h"

///////////////////////////////////////////////////////////////////////////

RenumKicadPCB_Base::RenumKicadPCB_Base( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxFrame( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	this->SetBackgroundColour( wxSystemSettings::GetColour( wxSYS_COLOUR_WINDOW ) );

	m_menubar = new wxMenuBar( 0 );
	RenumMenuAbout = new wxMenu();
	wxMenuItem* SayAbout;
	SayAbout = new wxMenuItem( RenumMenuAbout, wxID_ANY, wxString( _("&About") ) , wxEmptyString, wxITEM_NORMAL );
	RenumMenuAbout->Append( SayAbout );

	m_menubar->Append( RenumMenuAbout, _("&About") );

	m_ReadMe = new wxMenu();
	wxMenuItem* SayReadMe;
	SayReadMe = new wxMenuItem( m_ReadMe, wxID_ANY, wxString( _("&Read") ) , wxEmptyString, wxITEM_NORMAL );
	m_ReadMe->Append( SayReadMe );

	m_menubar->Append( m_ReadMe, _("&Read Me") );

	this->SetMenuBar( m_menubar );

	wxBoxSizer* bMainSizer;
	bMainSizer = new wxBoxSizer( wxVERTICAL );

	wxBoxSizer* bSizerProjectFilename;
	bSizerProjectFilename = new wxBoxSizer( wxVERTICAL );

	wxStaticText* staticProjectFileName;
	staticProjectFileName = new wxStaticText( this, wxID_ANY, _("Project file:"), wxDefaultPosition, wxDefaultSize, 0 );
	staticProjectFileName->Wrap( -1 );
	bSizerProjectFilename->Add( staticProjectFileName, 0, wxLEFT|wxRIGHT, 5 );

	m_ProjectFile = new wxFilePickerCtrl( this, wxID_ANY, wxEmptyString, _("Select a KiCad project file (*.pro)"), _("*.pro"), wxDefaultPosition, wxDefaultSize, wxFLP_DEFAULT_STYLE );
	m_ProjectFile->SetToolTip( _("Select a valid KiCad project with PCB and root schematic with the name.\nNOTE: The PCB or SCH files associated with the project must not be open in KiCad!\n") );

	bSizerProjectFilename->Add( m_ProjectFile, 1, wxALL|wxEXPAND, 5 );


	bMainSizer->Add( bSizerProjectFilename, 0, wxEXPAND|wxTOP, 10 );

	wxFlexGridSizer* fgSizer1;
	fgSizer1 = new wxFlexGridSizer( 6, 4, 0, 0 );
	fgSizer1->SetFlexibleDirection( wxBOTH );
	fgSizer1->SetNonFlexibleGrowMode( wxFLEX_GROWMODE_NONE );

	m_FrontSortDirText = new wxStaticText( this, wxID_ANY, _("Renumber Direction"), wxDefaultPosition, wxDefaultSize, 0 );
	m_FrontSortDirText->Wrap( -1 );
	m_FrontSortDirText->SetToolTip( _("Set the direction of sort: Top to Bottom, left to regith is as you read a book") );

	fgSizer1->Add( m_FrontSortDirText, 0, wxALL, 5 );

	wxString m_SortDirChoices[] = { _("Top to Bottom, Left to Right"), _("Top to Bottom, Right to Left"), _("Bottom to Top, Left to Right"), _("Bottom to Top, Right to Left"), _("Left to Right, Top to Bottom"), _("Left to Right, Bottom to Top"), _("Right to Left, Top to Bottom"), _("Right to Left, Bottom to Top") };
	int m_SortDirNChoices = sizeof( m_SortDirChoices ) / sizeof( wxString );
	m_SortDir = new wxChoice( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, m_SortDirNChoices, m_SortDirChoices, 0 );
	m_SortDir->SetSelection( 0 );
	m_SortDir->SetForegroundColour( wxSystemSettings::GetColour( wxSYS_COLOUR_WINDOWTEXT ) );
	m_SortDir->SetBackgroundColour( wxSystemSettings::GetColour( wxSYS_COLOUR_HIGHLIGHTTEXT ) );

	fgSizer1->Add( m_SortDir, 0, wxALL, 5 );

	m_BottomSortDirText = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_BottomSortDirText->Wrap( -1 );
	m_BottomSortDirText->SetToolTip( _("Set sort direction if looking at the solder side of the board") );

	fgSizer1->Add( m_BottomSortDirText, 0, wxALL, 5 );

	m_staticText15 = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText15->Wrap( -1 );
	fgSizer1->Add( m_staticText15, 0, wxALL, 5 );

	m_FrontRefDesStartText = new wxStaticText( this, wxID_ANY, _("Front Ref Des Start"), wxDefaultPosition, wxDefaultSize, 0 );
	m_FrontRefDesStartText->Wrap( -1 );
	m_FrontRefDesStartText->SetToolTip( _("Enter a number from 1-65,536") );

	fgSizer1->Add( m_FrontRefDesStartText, 0, wxALL, 5 );

	m_FrontRefDesStart = new wxTextCtrl( this, wxID_ANY, _("1"), wxDefaultPosition, wxSize( 100,-1 ), 0 );
	fgSizer1->Add( m_FrontRefDesStart, 0, wxALL, 5 );

	m_BottomRefDesStartText = new wxStaticText( this, wxID_ANY, _("Back Ref Des Start\n(Blank continues from Front)"), wxDefaultPosition, wxDefaultSize, 0 );
	m_BottomRefDesStartText->Wrap( -1 );
	m_BottomRefDesStartText->SetToolTip( _("Leave blank or zero, or enter a number greater than the highest reference designation on the component side. If there R100 is the highest component on the Front side, this number must be 101 or more.\n") );

	fgSizer1->Add( m_BottomRefDesStartText, 0, wxALL, 5 );

	m_BackRefDesStart = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 100,-1 ), 0 );
	fgSizer1->Add( m_BackRefDesStart, 0, wxALL, 5 );

	m_FrontPrefixText = new wxStaticText( this, wxID_ANY, _("Front Prefix"), wxDefaultPosition, wxDefaultSize, 0 );
	m_FrontPrefixText->Wrap( -1 );
	m_FrontPrefixText->SetToolTip( _("Optional prefix for component side reference designations (i.e. F_)") );

	fgSizer1->Add( m_FrontPrefixText, 0, wxALL, 5 );

	m_FrontPrefix = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 200,-1 ), 0 );
	fgSizer1->Add( m_FrontPrefix, 0, wxALL, 1 );

	m_BackPrefixText = new wxStaticText( this, wxID_ANY, _("Back Prefix"), wxDefaultPosition, wxDefaultSize, 0 );
	m_BackPrefixText->Wrap( -1 );
	m_BackPrefixText->SetToolTip( _("Optional prefix for solder side reference designations (i.e. B_)") );

	fgSizer1->Add( m_BackPrefixText, 0, wxALL, 5 );

	m_BackPrefix = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 200,-1 ), 0 );
	fgSizer1->Add( m_BackPrefix, 0, wxALL, 1 );

	m_RemoveFrontPrefix = new wxCheckBox( this, wxID_ANY, _("Remove Front Prefix"), wxDefaultPosition, wxDefaultSize, 0 );
	m_RemoveFrontPrefix->SetValue(true);
	m_RemoveFrontPrefix->SetToolTip( _("If checked will remove the component side prefix") );

	fgSizer1->Add( m_RemoveFrontPrefix, 0, wxALL, 5 );

	m_staticText31 = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText31->Wrap( -1 );
	fgSizer1->Add( m_staticText31, 0, wxALL, 5 );

	m_RemoveBackPrefix = new wxCheckBox( this, wxID_ANY, _("Remove Back Prefix"), wxDefaultPosition, wxDefaultSize, 0 );
	m_RemoveBackPrefix->SetToolTip( _("If checked will remove the Bottom side prefix") );

	fgSizer1->Add( m_RemoveBackPrefix, 0, wxALL, 5 );

	m_staticText35 = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText35->Wrap( -1 );
	fgSizer1->Add( m_staticText35, 0, wxALL, 5 );

	m_SortGridText = new wxStaticText( this, wxID_ANY, _("Sort Grid"), wxDefaultPosition, wxDefaultSize, 0 );
	m_SortGridText->Wrap( -1 );
	m_SortGridText->SetToolTip( _("Sets the \"rounding grid\" for sort: usually smaller for less dense boards (try 1.0 to start)") );

	fgSizer1->Add( m_SortGridText, 0, wxALL, 10 );

	m_SortGrid = new wxTextCtrl( this, wxID_ANY, _("1.000"), wxDefaultPosition, wxSize( 200,-1 ), 0 );
	fgSizer1->Add( m_SortGrid, 0, wxALL, 10 );

	m_SortOnModules = new wxRadioButton( this, wxID_ANY, _("Sort on Module Coordinates"), wxDefaultPosition, wxDefaultSize, 0 );
	m_SortOnModules->SetValue( true );
	m_SortOnModules->SetToolTip( _("Sort on the origin of the module") );

	fgSizer1->Add( m_SortOnModules, 0, wxALL, 10 );

	m_SortOnRefDes = new wxRadioButton( this, wxID_ANY, _("Sort on Ref Des Coordinates"), wxDefaultPosition, wxDefaultSize, 0 );
	m_SortOnRefDes->SetToolTip( _("Sort on the origin of the reference designation of the module") );

	fgSizer1->Add( m_SortOnRefDes, 0, wxALL, 10 );

	m_WriteChangeFile = new wxCheckBox( this, wxID_ANY, _("Write change file"), wxDefaultPosition, wxDefaultSize, 0 );
	m_WriteChangeFile->SetToolTip( _("Write a \"Was/Is\" file with format Was->Is") );

	fgSizer1->Add( m_WriteChangeFile, 0, wxALL, 5 );

	m_staticText36 = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText36->Wrap( -1 );
	fgSizer1->Add( m_staticText36, 0, wxALL, 5 );

	m_staticText37 = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText37->Wrap( -1 );
	fgSizer1->Add( m_staticText37, 0, wxALL, 5 );

	m_WriteLogFile = new wxCheckBox( this, wxID_ANY, _("Generate log file"), wxDefaultPosition, wxDefaultSize, 0 );
	m_WriteLogFile->SetToolTip( _("Generate a log file (useful for debugging)") );

	fgSizer1->Add( m_WriteLogFile, 0, wxALL, 5 );


	bMainSizer->Add( fgSizer1, 1, wxEXPAND, 5 );

	wxBoxSizer* bLowerSizer;
	bLowerSizer = new wxBoxSizer( wxVERTICAL );

	bLowerSizer->SetMinSize( wxSize( 660,250 ) );
	m_MessageWindow = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE|wxTE_RICH|wxTE_RICH2 );
	bLowerSizer->Add( m_MessageWindow, 1, wxALIGN_TOP|wxALL|wxEXPAND, 5 );


	bMainSizer->Add( bLowerSizer, 1, wxEXPAND, 1 );

	wxBoxSizer* bSizer9;
	bSizer9 = new wxBoxSizer( wxHORIZONTAL );

	wxGridSizer* gSizer1;
	gSizer1 = new wxGridSizer( 0, 4, 0, 0 );

	m_RenumberButton = new wxButton( this, wxID_ANY, _("Renumber"), wxDefaultPosition, wxDefaultSize, 0 );
	m_RenumberButton->SetToolTip( _("Renumber the board and back-annotate the schematics") );

	gSizer1->Add( m_RenumberButton, 0, wxALL|wxEXPAND, 5 );

	m_staticText38 = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText38->Wrap( -1 );
	gSizer1->Add( m_staticText38, 0, wxALL, 5 );

	m_staticText381 = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText381->Wrap( -1 );
	gSizer1->Add( m_staticText381, 0, wxALL, 5 );

	m_ExitButton = new wxButton( this, wxID_ANY, _("Exit"), wxDefaultPosition, wxDefaultSize, 0 );
	m_ExitButton->SetToolTip( _("Exit without saving the parameters") );

	gSizer1->Add( m_ExitButton, 0, wxALL|wxEXPAND, 5 );


	bSizer9->Add( gSizer1, 1, wxEXPAND, 5 );


	bMainSizer->Add( bSizer9, 0, wxEXPAND|wxLEFT, 5 );


	this->SetSizer( bMainSizer );
	this->Layout();

	this->Centre( wxBOTH );

	// Connect Events
	this->Connect( wxEVT_SIZE, wxSizeEventHandler( RenumKicadPCB_Base::MainSize ) );
	RenumMenuAbout->Bind(wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler( RenumKicadPCB_Base::SayAbout ), this, SayAbout->GetId());
	m_ReadMe->Bind(wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler( RenumKicadPCB_Base::SayReadMe ), this, SayReadMe->GetId());
	m_ProjectFile->Connect( wxEVT_COMMAND_FILEPICKER_CHANGED, wxFileDirPickerEventHandler( RenumKicadPCB_Base::ProjectFileSel ), NULL, this );
	m_RenumberButton->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( RenumKicadPCB_Base::OnRenumberClick ), NULL, this );
	m_ExitButton->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( RenumKicadPCB_Base::OKDone ), NULL, this );
}

RenumKicadPCB_Base::~RenumKicadPCB_Base()
{
	// Disconnect Events
	this->Disconnect( wxEVT_SIZE, wxSizeEventHandler( RenumKicadPCB_Base::MainSize ) );
	m_ProjectFile->Disconnect( wxEVT_COMMAND_FILEPICKER_CHANGED, wxFileDirPickerEventHandler( RenumKicadPCB_Base::ProjectFileSel ), NULL, this );
	m_RenumberButton->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( RenumKicadPCB_Base::OnRenumberClick ), NULL, this );
	m_ExitButton->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( RenumKicadPCB_Base::OKDone ), NULL, this );

}

ReadMeDialog_Base::ReadMeDialog_Base( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );

	wxBoxSizer* bSizer6;
	bSizer6 = new wxBoxSizer( wxVERTICAL );

	ReadMeBox = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE );
	bSizer6->Add( ReadMeBox, 1, wxALL|wxEXPAND, 5 );

	CloseReadMeDialog = new wxButton( this, wxID_ANY, _("Close"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer6->Add( CloseReadMeDialog, 0, wxALIGN_CENTER|wxALL, 5 );


	this->SetSizer( bSizer6 );
	this->Layout();

	this->Centre( wxBOTH );

	// Connect Events
	CloseReadMeDialog->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( ReadMeDialog_Base::CloseReadMe ), NULL, this );
}

ReadMeDialog_Base::~ReadMeDialog_Base()
{
	// Disconnect Events
	CloseReadMeDialog->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( ReadMeDialog_Base::CloseReadMe ), NULL, this );

}

AboutDialog_Base::AboutDialog_Base( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );

	wxBoxSizer* bSizer6;
	bSizer6 = new wxBoxSizer( wxVERTICAL );

	AboutBox = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE );
	bSizer6->Add( AboutBox, 1, wxALL|wxEXPAND, 5 );

	CloseAboutDialog = new wxButton( this, wxID_ANY, _("Close"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer6->Add( CloseAboutDialog, 0, wxALIGN_CENTER|wxALL, 5 );


	this->SetSizer( bSizer6 );
	this->Layout();

	this->Centre( wxBOTH );

	// Connect Events
	CloseAboutDialog->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( AboutDialog_Base::CloseAbout ), NULL, this );
}

AboutDialog_Base::~AboutDialog_Base()
{
	// Disconnect Events
	CloseAboutDialog->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( AboutDialog_Base::CloseAbout ), NULL, this );

}

ContinueAbort_Base::ContinueAbort_Base( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	this->SetFont( wxFont( wxNORMAL_FONT->GetPointSize(), wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD, false, wxEmptyString ) );

	wxBoxSizer* bSizer99;
	bSizer99 = new wxBoxSizer( wxHORIZONTAL );

	wxStaticBoxSizer* sbErrorAbort;
	sbErrorAbort = new wxStaticBoxSizer( new wxStaticBox( this, wxID_ANY, _("Errors found: continue?") ), wxHORIZONTAL );

	m_Continue = new wxButton( sbErrorAbort->GetStaticBox(), wxID_ANY, _("Write Files Anyway"), wxDefaultPosition, wxDefaultSize, 0 );
	sbErrorAbort->Add( m_Continue, 0, wxALL, 5 );

	m_Abort = new wxButton( sbErrorAbort->GetStaticBox(), wxID_ANY, _("DIscard Changes"), wxDefaultPosition, wxDefaultSize, 0 );
	sbErrorAbort->Add( m_Abort, 0, wxALL, 5 );


	bSizer99->Add( sbErrorAbort, 1, wxEXPAND, 5 );


	this->SetSizer( bSizer99 );
	this->Layout();

	this->Centre( wxBOTH );

	// Connect Events
	m_Continue->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( ContinueAbort_Base::ErrorContinue ), NULL, this );
	m_Abort->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( ContinueAbort_Base::ErrorAbort ), NULL, this );
}

ContinueAbort_Base::~ContinueAbort_Base()
{
	// Disconnect Events
	m_Continue->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( ContinueAbort_Base::ErrorContinue ), NULL, this );
	m_Abort->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( ContinueAbort_Base::ErrorAbort ), NULL, this );

}

Abort_Base::Abort_Base( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	this->SetFont( wxFont( wxNORMAL_FONT->GetPointSize(), wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD, false, wxEmptyString ) );

	wxBoxSizer* bSizer99;
	bSizer99 = new wxBoxSizer( wxHORIZONTAL );

	m_Continue = new wxButton( this, wxID_ANY, _("OK Try Again"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer99->Add( m_Continue, 0, wxALIGN_CENTER|wxALL, 5 );


	this->SetSizer( bSizer99 );
	this->Layout();

	this->Centre( wxBOTH );

	// Connect Events
	m_Continue->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Abort_Base::ErrorContinue ), NULL, this );
}

Abort_Base::~Abort_Base()
{
	// Disconnect Events
	m_Continue->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Abort_Base::ErrorContinue ), NULL, this );

}
