/*
 * RenumDefines.h
 */

#ifndef RENUMDEFINES_H_
#define RENUMDEFINES_H_

#include        "RenumLiterals.h"
#include        "RenumKicadPCBClasses.h"
#include        "RenumPrototypes.h"
#include        "RenumStructures.h"
#include		<sys/stat.h>	
#include        <string.h>

bool            G_SortYFirst, G_DescendingFirst, G_DescendingSecond;
bool            G_SortOnModules;      //Sort on modules/ref des
bool            G_RemoveFrontPrefix;
bool            G_RemoveBackPrefix;
bool            G_WriteLogFile;
bool            G_WriteChangeFile;
bool            G_NetlistError;

int             G_Errcount;           //The error count
int             G_SortCode;          //The sort code (left to right, etc.)
unsigned int    G_FrontStartRefDes;     //The starting Front ref des;;
unsigned int    G_BackStartRefDes;  //The starting Back ref des
int             G_Modules;

double          G_SortGrid;           //The sort grid

struct          KiCadFile   G_Netlist;
struct          KiCadFile   G_PCBInputFile;

std::string     G_FrontLayerName;

std::string     G_FrontPrefix;             //The Front Prefix std::string
std::string     G_BackPrefix;             //The Back Prefix std::string
std::string     G_LogFile;

std::vector     <RefDesChange> G_ChangeArray;
std::vector     <KiCadFile> G_AllSchematics;
std::vector     <PCBModule> G_FrontModules;
std::vector     <PCBModule> G_BackModules;
std::vector     <RefDesTypeStruct> G_RefDesTypes;

FileName        G_ProjectName;

RenumKicadPCB   *G_RenumMenu;
AboutDialog     *G_AboutDialog;
ReadMeDialog    *G_ReadMeDialog;

wxSize          G_MainDialogSize;           //Size of the main dialog

//
// This converts the index into a sort code. Note that Back sort code will have left and right swapped.
//
int     G_FrontDirectionsArray[] =
{
        SORTYFIRST + ASCENDINGFIRST + ASCENDINGSECOND,   //"Front to Back, left to right",
        SORTYFIRST + ASCENDINGFIRST + DESCENDINGSECOND,  //"Front to Back, right to left",
        SORTYFIRST + DESCENDINGFIRST + ASCENDINGSECOND,  //"Back to Front, left to right",
        SORTYFIRST + DESCENDINGFIRST + DESCENDINGSECOND, //"Back to Front, right to left",
        SORTXFIRST + ASCENDINGFIRST + ASCENDINGSECOND,   //"Left to right, Front to Back",
        SORTXFIRST + ASCENDINGFIRST + DESCENDINGSECOND,  //"Left to right, Back to Front",
        SORTXFIRST + DESCENDINGFIRST + ASCENDINGSECOND,  //"Right to left, Front to Back",
        SORTXFIRST + DESCENDINGFIRST + DESCENDINGSECOND  //"Right to left, Back to Front",
};

//
// Back Left/Right is opposite because it is a mirror image (coordinates are from the top)
//
int     G_BackDirectionsArray[] =
{
        SORTYFIRST + ASCENDINGFIRST + DESCENDINGSECOND,  //"Top to bottom, left to right",
        SORTYFIRST + ASCENDINGFIRST + ASCENDINGSECOND,   //"Top to bottom, right to left",
        SORTYFIRST + DESCENDINGFIRST + DESCENDINGSECOND, //"Bottom to top, left to right",
        SORTYFIRST + DESCENDINGFIRST + ASCENDINGSECOND,  //"Bottom to top, right to left",
        SORTXFIRST + DESCENDINGFIRST + ASCENDINGSECOND,  //"Left to right, top to bottom",
        SORTXFIRST + DESCENDINGFIRST + DESCENDINGSECOND, //"Left to right, bottom to top",
        SORTXFIRST + ASCENDINGFIRST + ASCENDINGSECOND,   //"Right to left, top to bottom",
        SORTXFIRST + ASCENDINGFIRST + DESCENDINGSECOND   //"Right to left, bottom to top",
};



const std::string ParameterList[] =
{
    "Project",                                 //0
    "FrontPrefix",                               //1
    "RemoveFrontPrefix",                         //2
    "BackPrefix",                            //3
    "RemoveBackPrefix",                         //4
    "SortCode",                                //5
    "FrontRefDesStart",                          //6
    "BackRefDesStart",                          //7
    "SortonModules",                           //8
    "SortGrid",                                //9
    "WriteChangeFile",                         //10
    "WriteLogFile",                            //11
    "MainSize",                                //12
    ""
};


#endif /* RENUMDEFINES_H_ */
