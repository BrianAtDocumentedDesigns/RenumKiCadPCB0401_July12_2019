If you get a “DLL not found” message, run and install vc_redist.x86.exe from https://support.microsoft.com/en-ca/help/2977003/the-latest-supported-visualc-downloads, which has the distributable DLLs. 

If you get "ucrtbase.dll" or "ucrtbased.dll" missing copy the file from C:\Windows\System32\ or whereever
it happens to be on your computer to whereever RenumKiCadPCB.exe is located. It is not clear whether this
is a Windows problem associated with an old version of Windows 10 or a Microsoft Studio problem.

