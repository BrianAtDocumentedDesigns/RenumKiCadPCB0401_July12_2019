/*
 * RenumStructures.h
 *
 *  Created on: Mar. 30, 2019
 *      Author: BrianP
 */

#ifndef RENUMSTRUCTURES_H_
#define RENUMSTRUCTURES_H_

#include    <string>
#include    "RenumLiterals.h"
#include    "FileName.h"

enum PCBSide
{
    PCBFront = 0,
    PCBBack = 1
};


struct  RefDesChange
{
        std::string  NewRefDes;             //The new reference designation (F_U21)
        std::string  OldRefDesString;       //What the old refdes preamble + number was
        bool         Ignore;                //Used to skip (if #, etc)
        bool         Found;                 //Found the ref des in the schematic
        PCBSide      Side;
};

struct  KiCadFile
{
        FileName     filename;
        std::string  buffer;
        bool         scanned;
};

struct  PCBModule {
        char    layer;                      //What layer the module is on (usually 1 or 2)
        double  oldx,oldy;                  //Original X and Y coordinate of the module or refdes
        double  x, y;                       //X and Y coordinate of the module
        std::string     RefDesString;       //What its refdes is
        std::string     RefDesType;         //Keep the type for renumbering.
        unsigned        long RefDesNumber;  //Used for prefixes and checking starting Back refdes
        size_t          ModuleIndex;        //Where the module is in the PCB file
};

struct  RefDesTypeStruct {
        std::string  RefDesType;
        unsigned int RefDesCount;
};

struct  ModuleTextField {
        std::string  name;           //Name of the module text field
        std::string  layer;          //Layer it is on
};

#endif /* RENUMSTRUCTURES_H_ */
